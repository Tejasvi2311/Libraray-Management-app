from django.contrib import admin
from .models import add_books
from import_export.admin import ImportExportModelAdmin

# Register your models here.
@admin.register(add_books)
class userdat(ImportExportModelAdmin):
    pass
