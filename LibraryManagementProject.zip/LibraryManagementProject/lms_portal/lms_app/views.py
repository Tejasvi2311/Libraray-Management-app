from django.contrib.auth import authenticate, login
from django.shortcuts import render
from django.contrib import admin
from django.http import HttpResponse
from django.shortcuts import redirect

from .models import *

# Create your views here.

def home(request):
    return render(request,"home.html",context={"current_tab":"home"})

def add_book(request):
    return render(request,"add_book.html",context={"current_tab":"add_book"})

def search_book(request):
    return render(request,"search_book.html",context={"current_tab":"search_book"})

def issue_book(request):
    return render(request,"issue_book.html",context={"current_tab":"issue_book"})

def delete_book(request):
    return render(request,"delete_book.html",context={"current_tab":"delete_book"})

def shopping(request):
    return HttpResponse("Welcome Shopping!")

def save_student(request):
    stu_name=request.POST['Student_name']
    return render(request,"welcome.html",context={'stu_name':stu_name})
    '''stu_age = request.POST['Student_age']
    return render(request, "welcome.html", context={'stu_age': stu_age})'''



def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')  # Assuming 'index' is the name of the URL pattern for index.html
        else:
            error_message = 'Invalid username or password'
            return render(request, 'login.html', {'error_message': error_message})
    else:
        return render(request, 'login.html')


def index_view(request):
    return render(request, 'index.html')

def addbook_tab(request):
    add_book=add_books.objects.all()
    return render(request,"add_book.html",
                  context={"current_tab":"add_book",
                                                "add_book":add_book})
def save_book(request):
    book_item=add_books(book_name=request.POST['bookName'],
                       author_name=request.POST['authorName'],
                       publication=request.POST['publication'],
                       count=request.POST['count']
                        )

    book_item.save()
    return redirect('/add_book')