from django.db import models


class add_books(models.Model):
    def __str__(self):
        return self.book_name
    book_name=models.TextField()
    author_name=models.CharField(max_length=200)
    publication=models.TextField()
    count=models.CharField(max_length=200)
    class Meta:
        db_table='add_books'
